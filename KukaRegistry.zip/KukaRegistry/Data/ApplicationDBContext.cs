﻿using KukaRegistry.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace KukaRegistry.Data
{
    public class ApplicationDBContext: DbContext
    {
        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options) 
        { 
        }
        
        public DbSet<Customers> Customers {  get; set; }
        public DbSet<Robots> Robots { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Robots>()
                .HasOne(r => r.Customer)
                .WithMany(c => c.Robots)
                .HasForeignKey(r => r.CustomerId)
                .OnDelete(DeleteBehavior.Restrict); //  delete related robots on customer deletion

            base.OnModelCreating(modelBuilder);
        }
    }
}
