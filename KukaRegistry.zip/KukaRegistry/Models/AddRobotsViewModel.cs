﻿using KukaRegistry.Models.Entities;

namespace KukaRegistry.Models
{
    public class AddRobotsViewModel
    {
        public string RobotName { get; set; }
        public string RobotModel { get; set; }
        public string RobotType { get; set; }
        public string RobotSN { get; set; }
        public string ControllerSN { get; set; }
        public string PCSN { get; set; }
        public string CommEngineer { get; set; }
        public string KSSVersion { get; set; }

        // Dropdown list of customers
        public List<CustomerViewModel> Customers { get; set; }

        // Selected customer ID
        public Guid SelectedCustomerId { get; set; }
    }

    public class CustomerViewModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }  // Display name for dropdown
    }
}
