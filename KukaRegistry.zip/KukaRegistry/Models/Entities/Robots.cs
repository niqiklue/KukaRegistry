﻿namespace KukaRegistry.Models.Entities
{
    public class Robots
    {
        public Guid Id { get; set; }
        public string RobotName { get; set; }
        public string RobotModel { get; set; }
        public string RobotType { get; set; }
        public string RobotSN { get; set; }
        public string ControllerSN { get; set; }
        public string PCSN { get; set; }
        public string CommEngineer { get; set; }
        public string KSSVersion { get; set; }

        // Foreign key
        public Guid CustomerId { get; set; }

        // Navigation property
        public Customers Customer { get; set; }
    }
}
