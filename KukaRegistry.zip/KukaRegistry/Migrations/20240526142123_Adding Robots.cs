﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace KukaRegistry.Migrations
{
    /// <inheritdoc />
    public partial class AddingRobots : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Robots",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    RobotName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RobotModel = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RobotType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RobotSN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ControllerSN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PCSN = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CommEngineer = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    KSSVersion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CustomerId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Robots", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Robots_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Robots_CustomerId",
                table: "Robots",
                column: "CustomerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Robots");
        }
    }
}
