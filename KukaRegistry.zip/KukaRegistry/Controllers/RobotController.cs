﻿using KukaRegistry.Data;
using KukaRegistry.Models.Entities;
using KukaRegistry.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks; // Needed for async operations

namespace KukaRegistry.Controllers
{
    public class RobotController : Controller
    {
        private readonly ApplicationDBContext dbContext;

        public RobotController(ApplicationDBContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Add()
        {
            var viewModel = new AddRobotsViewModel
            {
                Customers = dbContext.Customers
                    .Select(c => new CustomerViewModel { Id = c.Id, Name = c.Name })
                    .ToList()
            };

            return View(viewModel);
        }

        [HttpPost]
        public async Task<IActionResult> Add(AddRobotsViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                

              // saving to database:
                var robot = new Robots
                {
                    RobotName = viewModel.RobotName,
                    RobotModel = viewModel.RobotModel,
                    RobotType = viewModel.RobotType,
                    RobotSN = viewModel.RobotSN,
                    ControllerSN = viewModel.ControllerSN,
                    PCSN = viewModel.PCSN,
                    CommEngineer = viewModel.CommEngineer,
                    KSSVersion = viewModel.KSSVersion,
                    CustomerId = viewModel.SelectedCustomerId  // Assign selected customer ID
                };

                dbContext.Robots.Add(robot);
                await dbContext.SaveChangesAsync(); // Await the SaveChangesAsync method

                // Redirect to a success page or another action
                return RedirectToAction("Index", "Home");
            }

            // If ModelState is not valid, re-render the view with the viewModel
            
            viewModel.Customers = dbContext.Customers
                .Select(c => new CustomerViewModel { Id = c.Id, Name = c.Name })
                .ToList();

            return View(viewModel);
        }
    }
}
