﻿using Microsoft.AspNetCore.Mvc;
using KukaRegistry.Models;
using KukaRegistry.Data;
using KukaRegistry.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks; // Needed for async operations

namespace KukaRegistry.Controllers
{
    public class CustomersController : Controller
    {
        private readonly ApplicationDBContext dbContext;

        public CustomersController(ApplicationDBContext dbContext)
        {
            this.dbContext = dbContext;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]

        public async Task<IActionResult> Add(AddCustomerViewModel viewModel)
        {
            var customers = new Customers
            {

                CustomerCode = viewModel.CustomerCode,
                Name = viewModel.Name,
                VATno = viewModel.VATno,
                Address = viewModel.Address,
                Country = viewModel.Country,
                PostalCode = viewModel.PostalCode,
                Email = viewModel.Email,
            };

            await dbContext.Customers.AddAsync(customers);

            await dbContext.SaveChangesAsync();


            return View();
        }

        [HttpGet]
        public async Task<IActionResult> List()
        {
           var customers =  await dbContext.Customers.ToListAsync();

            return View(customers);

        }
    }
}
